﻿using CleanArchWebShop.Core.Services;

namespace CleanArchWebShop.UnitTests.Core.Services;

public class DeleteContributorService_DeleteContributor
{
  private readonly IRepository<Contributor> _repository = Substitute.For<IRepository<Contributor>>();
  private readonly IMediator _mediator = Substitute.For<IMediator>();
  private readonly ILogger<DeleteContributorService> _logger = Substitute.For<ILogger<DeleteContributorService>>();

  private readonly DeleteContributorService _service;

  public DeleteContributorService_DeleteContributor()
  {
    _service = new DeleteContributorService(_repository, _mediator, _logger);
  }

  [Fact]
  public async Task ReturnsNotFoundGivenCantFindContributor()
  {
    int missingId = 9999;
    var result = await _service.DeleteContributor(ContributorId.From(missingId));

    result.Status.ShouldBe(Ardalis.Result.ResultStatus.NotFound);
  }
}
