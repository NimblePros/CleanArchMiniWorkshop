using CleanArchWebShop.Core.OrderAggregate;
using CleanArchWebShop.UseCases.Orders.PlaceOrder;

namespace CleanArchWebShop.UnitTests.UseCases.Orders;

public class PlaceOrderCommandHandlerTests
{
  private readonly IRepository<Order> _repository = Substitute.For<IRepository<Order>>();
  private readonly PlaceOrderCommandHandler _handler;

  public PlaceOrderCommandHandlerTests()
  {
    // Configure the repository to return the order that was passed in
    _repository.AddAsync(Arg.Any<Order>(), Arg.Any<CancellationToken>())
      .Returns(callInfo => Task.FromResult(callInfo.Arg<Order>()));
    
    _handler = new PlaceOrderCommandHandler(_repository);
  }

  [Fact]
  public async Task Handle_ReturnsSuccess_WhenOrderIsValid()
  {
    // Arrange
    var command = new PlaceOrderCommand(
      UserId: "testuser",
      CustomerAddress: "123 Main St",
      ShippingOption: "Standard",
      PaymentMethod: "Credit Card",
      Items: new List<OrderItemRequest>
      {
        new(ItemId: 1, ItemName: "Laptop", UnitPrice: 999.99m, Quantity: 1)
      }
    );

    Order? capturedOrder = null;
    _repository.AddAsync(Arg.Do<Order>(o => capturedOrder = o), Arg.Any<CancellationToken>())
      .Returns(callInfo => Task.FromResult(callInfo.Arg<Order>()));

    // Act
    var result = await _handler.Handle(command, CancellationToken.None);

    // Assert
    result.IsSuccess.ShouldBeTrue();
    await _repository.Received(1).AddAsync(Arg.Any<Order>(), Arg.Any<CancellationToken>());
    
    capturedOrder.ShouldNotBeNull();
    capturedOrder.UserId.ShouldBe("testuser");
    capturedOrder.CustomerAddress.ShouldBe("123 Main St");
    capturedOrder.OrderItems.Count.ShouldBe(1);
    capturedOrder.Status.ShouldBe(OrderStatus.Completed);
    capturedOrder.TotalAmount.ShouldBe(999.99m);
  }

  [Fact]
  public async Task Handle_ReturnsError_WhenNoItemsProvided()
  {
    // Arrange
    var command = new PlaceOrderCommand(
      UserId: "testuser",
      CustomerAddress: "123 Main St",
      ShippingOption: "Standard",
      PaymentMethod: "Credit Card",
      Items: new List<OrderItemRequest>()
    );

    // Act
    var result = await _handler.Handle(command, CancellationToken.None);

    // Assert
    result.IsSuccess.ShouldBeFalse();
    result.Errors.ShouldContain(e => e.Contains("at least one item"));
    await _repository.DidNotReceive().AddAsync(Arg.Any<Order>(), Arg.Any<CancellationToken>());
  }

  [Fact]
  public async Task Handle_CalculatesTotalCorrectly_WithMultipleItems()
  {
    // Arrange
    var command = new PlaceOrderCommand(
      UserId: "testuser",
      CustomerAddress: "123 Main St",
      ShippingOption: "Express",
      PaymentMethod: "PayPal",
      Items: new List<OrderItemRequest>
      {
        new(ItemId: 1, ItemName: "Laptop", UnitPrice: 999.99m, Quantity: 1),
        new(ItemId: 2, ItemName: "Mouse", UnitPrice: 29.99m, Quantity: 2),
        new(ItemId: 3, ItemName: "Keyboard", UnitPrice: 89.99m, Quantity: 1)
      }
    );

    Order? capturedOrder = null;
    _repository.AddAsync(Arg.Do<Order>(o => capturedOrder = o), Arg.Any<CancellationToken>())
      .Returns(callInfo => Task.FromResult(callInfo.Arg<Order>()));

    // Act
    var result = await _handler.Handle(command, CancellationToken.None);

    // Assert
    result.IsSuccess.ShouldBeTrue();
    capturedOrder.ShouldNotBeNull();
    capturedOrder.OrderItems.Count.ShouldBe(3);
    // 999.99 + (29.99 * 2) + 89.99 = 1149.96
    capturedOrder.TotalAmount.ShouldBe(1149.96m);
  }

  [Fact]
  public async Task Handle_ReturnsError_WhenDuplicateItemsProvided()
  {
    // Arrange
    var command = new PlaceOrderCommand(
      UserId: "testuser",
      CustomerAddress: "123 Main St",
      ShippingOption: "Standard",
      PaymentMethod: "Credit Card",
      Items: new List<OrderItemRequest>
      {
        new(ItemId: 1, ItemName: "Laptop", UnitPrice: 999.99m, Quantity: 1),
        new(ItemId: 1, ItemName: "Laptop", UnitPrice: 999.99m, Quantity: 1) // Duplicate
      }
    );

    // Act
    var result = await _handler.Handle(command, CancellationToken.None);

    // Assert
    result.IsSuccess.ShouldBeFalse();
    result.Errors.ShouldContain(e => e.Contains("already in the order"));
    await _repository.DidNotReceive().AddAsync(Arg.Any<Order>(), Arg.Any<CancellationToken>());
  }

  [Fact]
  public async Task Handle_SetsOrderStatusToCompleted()
  {
    // Arrange
    var command = new PlaceOrderCommand(
      UserId: "testuser",
      CustomerAddress: "123 Main St",
      ShippingOption: "Standard",
      PaymentMethod: "Credit Card",
      Items: new List<OrderItemRequest>
      {
        new(ItemId: 1, ItemName: "Laptop", UnitPrice: 999.99m, Quantity: 1)
      }
    );

    Order? capturedOrder = null;
    _repository.AddAsync(Arg.Do<Order>(o => capturedOrder = o), Arg.Any<CancellationToken>())
      .Returns(callInfo => Task.FromResult(callInfo.Arg<Order>()));

    // Act
    var result = await _handler.Handle(command, CancellationToken.None);

    // Assert
    result.IsSuccess.ShouldBeTrue();
    capturedOrder.ShouldNotBeNull();
    capturedOrder.Status.ShouldBe(OrderStatus.Completed);
  }

  [Fact]
  public async Task Handle_PreservesAllOrderProperties()
  {
    // Arrange
    var userId = "user123";
    var address = "456 Oak Avenue, Suite 200";
    var shipping = "Overnight";
    var payment = "Debit Card";

    var command = new PlaceOrderCommand(
      UserId: userId,
      CustomerAddress: address,
      ShippingOption: shipping,
      PaymentMethod: payment,
      Items: new List<OrderItemRequest>
      {
        new(ItemId: 5, ItemName: "Monitor", UnitPrice: 299.99m, Quantity: 2)
      }
    );

    Order? capturedOrder = null;
    _repository.AddAsync(Arg.Do<Order>(o => capturedOrder = o), Arg.Any<CancellationToken>())
      .Returns(callInfo => Task.FromResult(callInfo.Arg<Order>()));

    // Act
    var result = await _handler.Handle(command, CancellationToken.None);

    // Assert
    result.IsSuccess.ShouldBeTrue();
    capturedOrder.ShouldNotBeNull();
    capturedOrder.UserId.ShouldBe(userId);
    capturedOrder.CustomerAddress.ShouldBe(address);
    capturedOrder.ShippingOption.ShouldBe(shipping);
    capturedOrder.PaymentMethod.ShouldBe(payment);
  }
}
