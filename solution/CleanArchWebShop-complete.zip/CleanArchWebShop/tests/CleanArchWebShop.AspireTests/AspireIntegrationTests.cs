namespace CleanArchWebShop.AspireTests.Tests;

public class AspireIntegrationTests
{
    // Follow the link below to write you tests with Aspire
    // https://learn.microsoft.com/en-us/dotnet/aspire/testing/write-your-first-test?pivots=xunit
}
