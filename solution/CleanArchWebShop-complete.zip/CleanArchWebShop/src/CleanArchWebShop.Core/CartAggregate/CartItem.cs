namespace CleanArchWebShop.Core.CartAggregate;

public class CartItem : EntityBase, IAggregateRoot
{
  public string UserId { get; private set; } = string.Empty;
  public int ItemId { get; private set; }
  public string ItemName { get; private set; } = string.Empty;
  public decimal UnitPrice { get; private set; }
  public int Quantity { get; private set; }
  
  public decimal TotalPrice => UnitPrice * Quantity;

  // EF Core requires a parameterless constructor
  private CartItem() { }

  public CartItem(string userId, int itemId, string itemName, decimal unitPrice, int quantity)
  {
    UserId = Guard.Against.NullOrWhiteSpace(userId, nameof(userId));
    ItemId = Guard.Against.NegativeOrZero(itemId, nameof(itemId));
    ItemName = Guard.Against.NullOrWhiteSpace(itemName, nameof(itemName));
    UnitPrice = Guard.Against.Negative(unitPrice, nameof(unitPrice));
    Quantity = Guard.Against.NegativeOrZero(quantity, nameof(quantity));
  }

  public void UpdateQuantity(int newQuantity)
  {
    Quantity = Guard.Against.NegativeOrZero(newQuantity, nameof(newQuantity));
  }

  public void UpdatePrice(decimal newPrice)
  {
    UnitPrice = Guard.Against.Negative(newPrice, nameof(newPrice));
  }
}
