namespace CleanArchWebShop.Core.OrderAggregate;

public class OrderItem : EntityBase
{
  public int OrderId { get; private set; }
  public int ItemId { get; private set; }
  public string ItemName { get; private set; } = string.Empty;
  public int Quantity { get; private set; }
  public decimal UnitPrice { get; private set; }
  
  public decimal TotalPrice => Quantity * UnitPrice;

  // EF Core requires a parameterless constructor
  private OrderItem() { }

  public OrderItem(int itemId, string itemName, int quantity, decimal unitPrice)
  {
    Guard.Against.NegativeOrZero(itemId, nameof(itemId));
    Guard.Against.NullOrWhiteSpace(itemName, nameof(itemName));
    Guard.Against.NegativeOrZero(quantity, nameof(quantity));
    Guard.Against.Negative(unitPrice, nameof(unitPrice));

    ItemId = itemId;
    ItemName = itemName;
    Quantity = quantity;
    UnitPrice = unitPrice;
  }
}
