namespace CleanArchWebShop.Core.OrderAggregate;

public class Order : EntityBase, IAggregateRoot
{
  public string UserId { get; private set; } = string.Empty;
  public string CustomerAddress { get; private set; } = string.Empty;
  public string ShippingOption { get; private set; } = string.Empty;
  public string PaymentMethod { get; private set; } = string.Empty;
  public decimal TotalAmount { get; private set; }
  public DateTime OrderDate { get; private set; }
  public OrderStatus Status { get; private set; }

  private readonly List<OrderItem> _orderItems = new();
  public IReadOnlyCollection<OrderItem> OrderItems => _orderItems.AsReadOnly();

  // EF Core requires a parameterless constructor
  private Order() { }

  public Order(string userId, string customerAddress, string shippingOption, string paymentMethod)
  {
    UserId = Guard.Against.NullOrWhiteSpace(userId, nameof(userId));
    CustomerAddress = Guard.Against.NullOrWhiteSpace(customerAddress, nameof(customerAddress));
    ShippingOption = Guard.Against.NullOrWhiteSpace(shippingOption, nameof(shippingOption));
    PaymentMethod = Guard.Against.NullOrWhiteSpace(paymentMethod, nameof(paymentMethod));
    
    OrderDate = DateTime.UtcNow;
    Status = OrderStatus.Pending;
    TotalAmount = 0;
  }

  public void AddItem(int itemId, string itemName, int quantity, decimal unitPrice)
  {
    // Business Rule: Can't add items to a completed order
    if (Status == OrderStatus.Completed || Status == OrderStatus.Cancelled)
    {
      throw new InvalidOperationException($"Cannot add items to an order with status {Status}");
    }

    // Business Rule: Check if item already exists in order
    var existingItem = _orderItems.FirstOrDefault(i => i.ItemId == itemId);
    if (existingItem != null)
    {
      throw new InvalidOperationException($"Item {itemName} is already in the order");
    }

    var orderItem = new OrderItem(itemId, itemName, quantity, unitPrice);
    _orderItems.Add(orderItem);
    
    RecalculateTotal();
  }

  public void RemoveItem(int itemId)
  {
    // Business Rule: Can't modify completed orders
    if (Status == OrderStatus.Completed || Status == OrderStatus.Cancelled)
    {
      throw new InvalidOperationException($"Cannot remove items from an order with status {Status}");
    }

    var item = _orderItems.FirstOrDefault(i => i.ItemId == itemId);
    if (item == null)
    {
      throw new InvalidOperationException($"Item with id {itemId} not found in order");
    }

    _orderItems.Remove(item);
    RecalculateTotal();
  }

  public void Complete()
  {
    // Business Rule: Order must have items
    if (!_orderItems.Any())
    {
      throw new InvalidOperationException("Cannot complete an order with no items");
    }

    // Business Rule: Order must be pending
    if (Status != OrderStatus.Pending)
    {
      throw new InvalidOperationException($"Cannot complete an order with status {Status}");
    }

    Status = OrderStatus.Completed;
  }

  public void Cancel()
  {
    // Business Rule: Can't cancel completed orders
    if (Status == OrderStatus.Completed)
    {
      throw new InvalidOperationException("Cannot cancel a completed order");
    }

    Status = OrderStatus.Cancelled;
  }

  private void RecalculateTotal()
  {
    TotalAmount = _orderItems.Sum(item => item.TotalPrice);
  }
}
