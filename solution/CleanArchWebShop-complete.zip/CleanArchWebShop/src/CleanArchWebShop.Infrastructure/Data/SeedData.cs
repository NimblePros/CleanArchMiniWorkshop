﻿using CleanArchWebShop.Core.ContributorAggregate;
using CleanArchWebShop.Core.CartAggregate;

namespace CleanArchWebShop.Infrastructure.Data;

public static class SeedData
{
  public const int NUMBER_OF_CONTRIBUTORS = 27; // including the 2 below
  public static readonly Contributor Contributor1 = new(ContributorName.From("Ardalis"));
  public static readonly Contributor Contributor2 = new(ContributorName.From("Ilyana"));

  public static async Task InitializeAsync(AppDbContext dbContext)
  {
    if (await dbContext.Contributors.AnyAsync()) return; // DB has been seeded

    await PopulateTestDataAsync(dbContext);
  }

  public static async Task PopulateTestDataAsync(AppDbContext dbContext)
  {
    dbContext.Contributors.AddRange([Contributor1, Contributor2]);
    await dbContext.SaveChangesAsync();

    // add a bunch more contributors to support demonstrating paging
    for (int i = 1; i <= NUMBER_OF_CONTRIBUTORS-2; i++)
    {
      dbContext.Contributors.Add(new Contributor(ContributorName.From($"Contributor {i}")));
    }
    await dbContext.SaveChangesAsync();

    // Seed cart items if none exist
    if (!await dbContext.CartItems.AnyAsync())
    {
      var cartItems = new List<CartItem>
      {
        new CartItem("testuser", 1, "Laptop Computer", 999.99m, 1),
        new CartItem("testuser", 2, "Wireless Mouse", 29.99m, 2),
        new CartItem("testuser", 3, "Mechanical Keyboard", 89.99m, 1),
        
        // Sample cart items for user "user2"
        new CartItem("user2", 4, "Monitor 27 inch", 299.99m, 1),
        new CartItem("user2", 5, "Webcam HD", 79.99m, 1)
      };

      dbContext.CartItems.AddRange(cartItems);
      await dbContext.SaveChangesAsync();
    }
  }
}
