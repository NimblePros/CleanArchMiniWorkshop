using CleanArchWebShop.Core.OrderAggregate;

namespace CleanArchWebShop.Infrastructure.Data.Config;

public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
  public void Configure(EntityTypeBuilder<Order> builder)
  {
    builder.Property(o => o.UserId)
      .IsRequired()
      .HasMaxLength(450);

    builder.Property(o => o.CustomerAddress)
      .IsRequired()
      .HasMaxLength(500);

    builder.Property(o => o.ShippingOption)
      .IsRequired()
      .HasMaxLength(100);

    builder.Property(o => o.PaymentMethod)
      .IsRequired()
      .HasMaxLength(50);

    builder.Property(o => o.TotalAmount)
      .HasPrecision(18, 2)
      .IsRequired();

    builder.Property(o => o.Status)
      .IsRequired();

    // Configure the OrderItems collection with proper ownership
    builder.OwnsMany(o => o.OrderItems, oi =>
    {
      oi.Property(x => x.ItemName)
        .IsRequired()
        .HasMaxLength(200);

      oi.Property(x => x.Quantity)
        .IsRequired();

      oi.Property(x => x.UnitPrice)
        .HasPrecision(18, 2)
        .IsRequired();

      // TotalPrice is calculated, not stored
      oi.Ignore(x => x.TotalPrice);
    });

    // Index for common queries
    builder.HasIndex(o => o.UserId);
    builder.HasIndex(o => o.OrderDate);
  }
}
