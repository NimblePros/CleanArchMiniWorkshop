﻿using CleanArchWebShop.Core.ContributorAggregate;
using Vogen;

namespace CleanArchWebShop.Infrastructure.Data.Config;

[EfCoreConverter<ContributorId>]
[EfCoreConverter<ContributorName>]
internal partial class VogenEfCoreConverters;
