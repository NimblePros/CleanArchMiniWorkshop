using CleanArchWebShop.Core.CartAggregate;

namespace CleanArchWebShop.Infrastructure.Data.Config;

public class CartItemConfiguration : IEntityTypeConfiguration<CartItem>
{
  public void Configure(EntityTypeBuilder<CartItem> builder)
  {
    builder.Property(ci => ci.UserId)
      .IsRequired()
      .HasMaxLength(450); // Matches ASP.NET Identity user ID length

    builder.Property(ci => ci.ItemName)
      .IsRequired()
      .HasMaxLength(200);

    builder.Property(ci => ci.UnitPrice)
      .HasPrecision(18, 2)
      .IsRequired();

    builder.Property(ci => ci.Quantity)
      .IsRequired();

    // TotalPrice is calculated, not stored
    builder.Ignore(ci => ci.TotalPrice);

    // Index for common queries (get cart by user)
    builder.HasIndex(ci => ci.UserId);
  }
}
