﻿global using Ardalis.Result;
global using Ardalis.SharedKernel;
global using Mediator;
