using CleanArchWebShop.Core.OrderAggregate;

namespace CleanArchWebShop.UseCases.Orders.PlaceOrder;

public class PlaceOrderCommandHandler(IRepository<Order> orderRepository)
  : IRequestHandler<PlaceOrderCommand, Result<int>>
{
  public async ValueTask<Result<int>> Handle(PlaceOrderCommand request, CancellationToken cancellationToken)
  {
    // Validate that we have items
    if (request.Items == null || !request.Items.Any())
    {
      return Result<int>.Error("Order must contain at least one item");
    }

    // Create the order
    var order = new Order(
      request.UserId,
      request.CustomerAddress,
      request.ShippingOption,
      request.PaymentMethod
    );

    // Add items to the order
    foreach (var requestItem in request.Items)
    {
      try
      {
        order.AddItem(
          requestItem.ItemId,
          requestItem.ItemName,
          requestItem.Quantity,
          requestItem.UnitPrice
        );
      }
      catch (InvalidOperationException ex)
      {
        return Result<int>.Error(ex.Message);
      }
    }

    // Complete the order
    try
    {
      order.Complete();
    }
    catch (InvalidOperationException ex)
    {
      return Result<int>.Error(ex.Message);
    }

    // Save the order
    await orderRepository.AddAsync(order, cancellationToken);

    return Result<int>.Success(order.Id);
  }
}
