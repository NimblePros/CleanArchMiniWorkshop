namespace CleanArchWebShop.UseCases.Orders.PlaceOrder;

public record PlaceOrderCommand(
  string UserId,
  string CustomerAddress,
  string ShippingOption,
  string PaymentMethod,
  List<OrderItemRequest> Items
) : IRequest<Result<int>>;

public record OrderItemRequest(
  int ItemId,
  string ItemName,
  decimal UnitPrice,
  int Quantity
);
