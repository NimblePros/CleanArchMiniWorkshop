﻿namespace CleanArchWebShop.UseCases;

public class Constants
{
  public const int DEFAULT_PAGE_SIZE = 10;
  public const int MAX_PAGE_SIZE = 100;
}
