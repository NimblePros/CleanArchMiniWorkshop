﻿using CleanArchWebShop.Core.ContributorAggregate;

namespace CleanArchWebShop.UseCases.Contributors.Delete;

public record DeleteContributorCommand(ContributorId ContributorId) : ICommand<Result>;
