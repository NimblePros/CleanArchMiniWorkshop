﻿using CleanArchWebShop.Core.ContributorAggregate;

namespace CleanArchWebShop.UseCases.Contributors;
public record ContributorDto(ContributorId Id, ContributorName Name, PhoneNumber PhoneNumber);
