﻿using CleanArchWebShop.Core.ContributorAggregate;

namespace CleanArchWebShop.UseCases.Contributors.Get;

public record GetContributorQuery(ContributorId ContributorId) : IQuery<Result<ContributorDto>>;
