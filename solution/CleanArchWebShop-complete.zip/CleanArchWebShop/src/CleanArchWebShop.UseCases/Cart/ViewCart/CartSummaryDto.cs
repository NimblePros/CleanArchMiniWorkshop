namespace CleanArchWebShop.UseCases.Cart.ViewCart;

public record CartSummaryDto(
  string UserId,
  List<CartItemDto> Items,
  decimal SubTotal,
  int TotalItems
);

public record CartItemDto(
  int Id,
  int ItemId,
  string ItemName,
  decimal UnitPrice,
  int Quantity,
  decimal TotalPrice
);
