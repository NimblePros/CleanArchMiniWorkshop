namespace CleanArchWebShop.UseCases.Cart.ViewCart;

public record ViewCartQuery(
  string UserId
) : IRequest<Result<CartSummaryDto>>;
