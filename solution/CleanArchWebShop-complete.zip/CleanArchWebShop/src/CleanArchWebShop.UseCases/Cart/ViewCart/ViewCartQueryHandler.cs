using CleanArchWebShop.Core.CartAggregate;

namespace CleanArchWebShop.UseCases.Cart.ViewCart;

public class ViewCartQueryHandler(IReadRepository<CartItem> repository)
  : IRequestHandler<ViewCartQuery, Result<CartSummaryDto>>
{
  public async ValueTask<Result<CartSummaryDto>> Handle(
    ViewCartQuery request,
    CancellationToken cancellationToken)
  {
    // Get all cart items for this user
    var cartItems = await repository.ListAsync(cancellationToken);
    var userCartItems = cartItems.Where(ci => ci.UserId == request.UserId).ToList();
    
    // Map to DTOs
    var cartItemDtos = userCartItems.Select(ci => new CartItemDto(
      ci.Id,
      ci.ItemId,
      ci.ItemName,
      ci.UnitPrice,
      ci.Quantity,
      ci.TotalPrice
    )).ToList();
    
    // Calculate totals
    var subTotal = cartItemDtos.Sum(ci => ci.TotalPrice);
    var totalItems = cartItemDtos.Sum(ci => ci.Quantity);
    
    var cartSummary = new CartSummaryDto(
      request.UserId,
      cartItemDtos,
      subTotal,
      totalItems
    );
    
    return Result<CartSummaryDto>.Success(cartSummary);
  }
}
