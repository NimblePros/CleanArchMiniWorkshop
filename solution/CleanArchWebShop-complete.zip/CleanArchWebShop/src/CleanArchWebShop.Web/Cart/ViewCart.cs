using CleanArchWebShop.UseCases.Cart.ViewCart;

namespace CleanArchWebShop.Web.Cart;

public class ViewCart(IMediator mediator) : Endpoint<ViewCartRequest, CartSummaryDto>
{
  public override void Configure()
  {
    Get("/cart/{userId}");
    AllowAnonymous();

    Summary(s =>
    {
      s.Summary = "View shopping cart";
      s.Description = "Retrieves all items in the shopping cart for the specified user";
      s.ExampleRequest = new ViewCartRequest { UserId = "testuser" };

      s.Responses[200] = "Cart summary returned successfully";
      s.Responses[400] = "Invalid request";
    });

    Tags("Cart");

    Description(builder => builder
      .Accepts<ViewCartRequest>()
      .Produces<CartSummaryDto>(200, "application/json")
      .ProducesProblem(400));
  }

  public override async Task HandleAsync(ViewCartRequest req, CancellationToken ct)
  {
    var query = new ViewCartQuery(req.UserId);
    var result = await mediator.Send(query, ct);

    if (result.IsSuccess)
    {
      await Send.OkAsync(result.Value, ct);
    }
    else
    {
      await Send.ErrorsAsync(statusCode: 400, ct);
    }
  }
}

public class ViewCartRequest
{
  public string UserId { get; init; } = string.Empty;
}
