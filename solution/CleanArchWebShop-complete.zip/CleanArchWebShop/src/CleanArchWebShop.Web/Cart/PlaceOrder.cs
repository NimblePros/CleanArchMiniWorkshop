using CleanArchWebShop.UseCases.Orders.PlaceOrder;

namespace CleanArchWebShop.Web.Cart;

public class PlaceOrder(IMediator mediator) : Endpoint<PlaceOrderCommand>
{
  public override void Configure()
  {
    Post("/orders");
    AllowAnonymous();

    Summary(s =>
    {
      s.Summary = "Place a new order";
      s.Description = "Creates a new order with the specified items";

      s.Responses[201] = "Order created successfully";
      s.Responses[400] = "Invalid request or business rule violation";
    });

    Tags("Orders");

    Description(builder => builder
      .Accepts<PlaceOrderCommand>()
      .Produces(201)
      .ProducesProblem(400));
  }

  public override async Task HandleAsync(PlaceOrderCommand req, CancellationToken ct)
  {
    var result = await mediator.Send(req, ct);

    if (result.IsSuccess)
    {
      HttpContext.Response.StatusCode = 201;
      await Send.OkAsync(new { orderId = result.Value }, ct);
    }
    else
    {
      await Send.ErrorsAsync(statusCode: 400, ct);
    }
  }
}
