﻿namespace CleanArchWebShop.Web.Contributors;

public record ContributorRecord(int Id, string Name, string? PhoneNumber);
